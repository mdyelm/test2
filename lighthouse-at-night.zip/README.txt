A Pen created at CodePen.io. You can find this one at https://codepen.io/CameronFitzwilliam/pen/ZJoENR.

 I was originally going to make an SVG animation, but I thought I would have a go at CSS and torture myself. I also implement ParallaxJS so the user can distort the perspective.

Lighthouse in Night by Yup Nguyen

https://dribbble.com/shots/2728978-The-Lighthouse-In-Night-Animated/