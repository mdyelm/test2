A Pen created at CodePen.io. You can find this one at https://codepen.io/bartuc/pen/eEbmvJ.

 Messing around with reflections in threejs. Getting a feel for cubecameras and how to adjust settings. Playing with a lot of different mappings such as displacement, specular, environment, and normal.